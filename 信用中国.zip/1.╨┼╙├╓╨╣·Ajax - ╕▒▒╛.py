import requests,re,json
from lxml import etree
from urllib import parse

# url ='https://www.creditchina.gov.cn/xinyongxinxi/index.html?index=0&keyword=%E6%95%99%E8%82%B2'

def get_credit(kw):
    url='https://www.creditchina.gov.cn/api/credit_info_search?keyword={}&templateId=&page=1&pageSize=10'.format(kw)
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36'}
    proxy={'http':'194.186.173.6:54842','https':'185.251.219.17:53281'}
    response = requests.request('get',url=url,headers=headers).content.decode('utf-8')
    data_list =re.findall(r'{"name":.*?}',response)
    print(data_list)
    with open('xyzg.txt','a',encoding='utf-8')as f:
        for d in data_list:
            data=json.loads(d)
            # print(data)
            encryStr=data['encryStr'].replace('\n','')
            name = data['name'].replace('\n', '')
            f.write('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n')
            # print(encryStr)

            #信息概览
            base_url='https://www.creditchina.gov.cn/api/credit_info_detail?encryStr={}'.format(encryStr)
            response_info = requests.request('get',url=base_url,headers=headers).content.decode('utf-8')
            info_list = re.findall(r'{"id":.*}',response_info)
            f.write(str(info_list)+'\n')

            #行政许可
            xk_url='https://www.creditchina.gov.cn/api/pub_permissions_name?name={}&page=1&pageSize=10'.format(name)
            response_xk = requests.request('get',url=xk_url,headers=headers).content.decode('utf-8')
            # print(response_xk)
            xk_list = re.findall(r':\[(.*)\]',response_xk)
            # print(xk_list)
            f.write(str(xk_list)+'\n')

            #行政处罚
            cf_url = 'https://www.creditchina.gov.cn/api/pub_penalty_name?name={}&page=1&pageSize=10'.format(name)
            response_cf = requests.request('get', url=cf_url, headers=headers).content.decode('utf-8')
            cf_list = re.findall(r':\[(.*)\]',response_cf)
            f.write(str(cf_list)+'\n')

            #守信红名单
            sx_url = 'https://www.creditchina.gov.cn/api/record_param?encryStr={}&creditType=2&dataSource=0&pageNum=1&pageSize=10'.format(encryStr)
            response_sx = requests.request('get', url=sx_url, headers=headers).content.decode('utf-8')
            sx_list = re.findall(r':\[(.*)\]',response_sx)
            f.write(str(sx_list)+'\n')

            #重点关注名单
            url_zdgz ='https://www.creditchina.gov.cn/api/record_param?encryStr={}&creditType=4&dataSource=0&pageNum=1&pageSize=10'.format(encryStr)
            response_zdgz = requests.request('get',url=url_zdgz,headers=headers).content.decode('utf-8')
            # print(response_zdgz)
            zdgz_list = re.findall(r':\[(.*)\]',response_zdgz)
            # print(zdgz_list)
            f.write(str(zdgz_list)+'\n')

            #黑名单
            hmd_url ='https://www.creditchina.gov.cn/api/record_param?encryStr={}&creditType=8&dataSource=0&pageNum=1&pageSize=10'.format(encryStr)
            response_hmd = requests.request('get',url=hmd_url,headers=headers).content.decode('utf-8')
            hmd_list = re.findall(r':\[(.*)\]',response_hmd)
            f.write(str(hmd_list)+'\n')

if __name__ == '__main__':
    kw=input('请输入要查询的行业：')
    get_credit(kw)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~面向对象~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

'''

def detail(encryStr,name):
    # print(encryStr)
    # 信息概览
    base_url = 'https://www.creditchina.gov.cn/api/credit_info_detail?encryStr={}'.format(encryStr)
    response_info = requests.request('get', url=base_url, headers=headers).content.decode('utf-8')
    info_list = re.findall(r'{"id":.*?}', response_info)

    # 行政许可
    xk_url = 'https://www.creditchina.gov.cn/api/pub_permissions_name?name={}&page=1&pageSize=10'.format(name)
    response_xk = requests.request('get', url=xk_url, headers=headers).content.decode('utf-8')
    # print(response_xk)
    xk_list = re.findall(r':\[(.*)\]', response_xk)
    # print(xk_list)

    # 行政处罚
    cf_url = 'https://www.creditchina.gov.cn/api/pub_penalty_name?name={}&page=1&pageSize=10'.format(name)
    response_cf = requests.request('get', url=cf_url, headers=headers).content.decode('utf-8')
    cf_list = re.findall(r':\[(.*)\]', response_cf)

    # 守信红名单
    sx_url = 'https://www.creditchina.gov.cn/api/record_param?encryStr={}&creditType=2&dataSource=0&pageNum=1&pageSize=10'.format(
        encryStr)
    response_sx = requests.request('get', url=sx_url, headers=headers).content.decode('utf-8')
    sx_list = re.findall(r':\[(.*)\]', response_sx)

    # 重点关注名单
    url_zdgz = 'https://www.creditchina.gov.cn/api/record_param?encryStr={}&creditType=4&dataSource=0&pageNum=1&pageSize=10'.format(
        encryStr)
    response_zdgz = requests.request('get', url=url_zdgz, headers=headers).content.decode('utf-8')
    # print(response_zdgz)
    zdgz_list = re.findall(r':\[(.*)\]', response_zdgz)
    # print(zdgz_list)

    # 黑名单
    hmd_url = url5 = 'https://www.creditchina.gov.cn/api/record_param?encryStr={}&creditType=8&dataSource=0&pageNum=1&pageSize=10'.format(
        encryStr)
    response_hmd = requests.request('get', url=hmd_url, headers=headers).content.decode('utf-8')
    hmd_list = re.findall(r':\[(.*)\]', response_hmd)

'''

